# WhatsApp in Pure CSS and JS

A Pen created on CodePen.

Original URL: [https://codepen.io/swaibu/pen/QxJjwN](https://codepen.io/swaibu/pen/QxJjwN).

